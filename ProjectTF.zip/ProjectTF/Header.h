#pragma once
#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string>
#include <fstream>
#include <functional>
#include <vector>
#include <Windows.h>
#include <iomanip>
#include <stdio.h>
#include <list>
#include <sstream>

#define Pos Console::SetCursorPosition(70, 4)
#define Cls Console::Clear()
#define Print cout << "\n_______________________________________________________________________________________________________\n";Console::SetCursorPosition(0, 11)

using namespace System;
using namespace std;