#pragma once
#include <iostream>
#include <functional>
#include <vector>
#include <string>
using namespace std;
template<class G>
class Tree {
	template<class T>
	class Node {
	public:
		Node<T>* l, * r;
		T data;
		Node(T d) :data(d) { l = r = nullptr; }
	};
	Node<G>* root;
	bool(*cmp)(G, G);
	void (*imp)(G);
public:
	Tree(bool(*cmp)(G, G), void (*imp)(G)) :cmp(cmp), imp(imp) { root = nullptr; }
	void insert(G e, Node<G>*& tmp) {
		if (tmp == nullptr)
			tmp = new Node<G>(e);
		else if (cmp(e, tmp->data))
			insert(e, tmp->r);
		else insert(e, tmp->l);

	}
	void insert(G e) {
		insert(e, root);
	}
	void print() { print(root); }
	void print(Node<G>* tmp) {
		if (tmp == nullptr)return;
		print(tmp->l);
		imp(tmp->data);
		print(tmp->r);
	}
	void preOrden(Node<G>* tmp) {
		if (tmp == nullptr)return;
		imp(tmp->data);
		preOrden(tmp->l);
		preOrden(tmp->r);
	}
	void PreOrden() {
		preOrden(root);
	}
	void postOrden(Node<G>* tmp) {
		if (tmp == nullptr)return;
		postOrden(tmp->l);
		postOrden(tmp->r);
		imp(tmp->data);
	}
	void PostOrden() {
		postOrden(root);
	}
	void enOrden(Node<G>* tmp) {
		if (tmp == nullptr) return;
		enOrden(tmp->l);
		imp(tmp->data);
		enOrden(tmp->r);
	}
	void EnOrden() {
		enOrden(root);
	}
	bool search(Node<G>* tmp, G e) {
		if (tmp == nullptr) return false;
		else if (tmp->l == nullptr || tmp->r == nullptr) return true;
		else
		{
			int r = cmp(tmp->data, e);
			if (r == 0) return true;
			else if (r < 0) { return search(tmp->r, e); }
			else { return search(tmp->l, e); }
		}
	}
	void buscar(G e) {
		if (!search(root, e))
			cout << "No se encontro" << endl;
		else
			cout << "Se encontro" << endl;
	}
	Node<G> obtener(Node<G>* tmp, short e) {
		if (tmp == nullptr) return nullptr;
		else
		{
			int r = cmp(tmp->data, e);
			if (r == 0) return tmp;
			else if (r < 0) return search(tmp->r, e);
			else return search(tmp->l, e);
		}
	}
	void Obtener(short e) {
		imp(obtener(root, e));
	}
	bool isEmpty() {
		return root == nullptr;
	}
	int cantElements(Node<G>* tmp) {
		if (tmp == nullptr) return 0;
		else
		{
			int ci, cd;
			ci = cantElements(tmp->l);
			cd = cantElements(tmp->r);
			return 1 + ci + cd;
		}
	}
	void Cantidad() {
		cout << "\n" << cantElements(root) << endl;
	}
	int altura(Node<G>* tmp) {
		if (tmp == nullptr) return 0;
		else
		{
			int hi, hd;
			hi = 1 + altura(tmp->l);
			hd = 1 + altura(tmp->r);
			return hi > hd ? hi : hd;
		}
	}
	void Altura() {
		cout << "\n" << altura(root) << endl;
	}
	G minimo(Node<G>* tmp) {
		if (tmp->l == nullptr) return tmp->data;
		else return minimo(tmp->l);
	}
	void Minimo() {
		imp(minimo(root));
	}
	G maximo(Node<G>* tmp) {
		if (tmp->r == nullptr) return tmp->data;
		else return maximo(tmp->r);
	}
	void Maximo() {
		imp(maximo(root));
	}
	bool eliminar(Node<G>* tmp, G e) {
		if (tmp == nullptr) return false;
		else
		{
			int r = cmp(tmp->data, e);
			if (r < 0) { return eliminar(tmp->r, e); }
			else if (r > 0) { return eliminar(tmp->l, e); }
			else {
				if (tmp->r == nullptr && tmp->l == nullptr) {
					tmp = nullptr;
					delete tmp;
					return true;
				}
				else if (tmp->l == nullptr) {
					tmp = tmp->r;
					return true;
				}
				else if (tmp->r == nullptr) {
					tmp = tmp->l;
					return true;
				}
				else
				{
					Node<G>* aux = tmp->r;
					while (aux->l != nullptr) {
						aux = aux->l;
					}
					tmp->data = aux->data;
					return eliminar(tmp->r, aux->data);
				}
			}
		}
	}
	void Eliminar(G e) {
		if (eliminar(root, e))
			cout << "\nElemento eliminado\n";
		else
			cout << "\nElemento no eliminado\n";
	}


};